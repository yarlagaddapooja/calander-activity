import React, { useState } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import listPlugin from "@fullcalendar/list";
import { Modal, DatePicker, Input, Button } from 'antd';
import moment from 'moment';
import './App.css';

function App() {
  const [modalOpen, setModalOpen] = useState(false);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [eventTitle, setEventTitle] = useState('');
  const [events, setEvents] = useState([
    { title: 'Event 1', date: '2024-04-16' },
    { title: 'Event 2', date: '2024-04-17' }
  ]);
  const [showAlert, setShowAlert] = useState(false);

  const handleDateClick = (arg) => {
    const clickedDate = moment(arg.date);
    console.log("clickedDate",clickedDate)
    const currentDate = moment();
    console.log('currentDate',currentDate)

    if (clickedDate.isBefore(currentDate, 'day')) {
      // Show the alert for past dates
      setShowAlert(true);
      return;
    }

    setStartDate(clickedDate.clone());
    setEndDate(clickedDate.clone());
    setEventTitle('');
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setShowAlert(false); // Close the modal message when closing the modal
  };

  const handleSaveEvent = () => {
    const currentDate = moment();

    if (startDate.isBefore(currentDate, 'day')) {
      // Show the modal message for past dates
      setShowAlert(true);
      return;
    }

    const newEvent = {
      title: eventTitle,
      start: startDate.toISOString(),
      end: endDate.toISOString()
    };

    setEvents([...events, newEvent]);
    closeModal();
  };

  const onChangeStartDate = (date, dateString) => {
    setStartDate(date,dateString);
    console.log("onchange start date",date,dateString)
  };

  const onChangeEndDate = (date, dateString) => {
    setEndDate(date,dateString);
    console.log("onchange End date",date,dateString)
  };
 
  const handleTitleChange = (e) => {
    setEventTitle(e.target.value);
  };

  return (
    <div className="App">
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin, listPlugin]}
        headerToolbar={{
          left: "prev,next today",
          center: "title",
          right: "dayGridMonth,timeGridWeek,timeGridDay,listMonth",
        }}
        initialView="dayGridMonth"
        weekends={true}
        events={events}
        dateClick={handleDateClick}
      />
      <Modal
        title="Add Event"
        open={modalOpen}
        onCancel={closeModal}
        footer={[
          <Button key="cancel" onClick={closeModal}>Cancel</Button>,
          <Button key="save" type="primary" onClick={handleSaveEvent}>Save</Button>
        ]}
      >
        <label className="modal-label" htmlFor="title">Title:</label>
        <Input
          className="modal-input"
          placeholder="Title"
          value={eventTitle}
          onChange={handleTitleChange}
        />
        <label className="modal-label" htmlFor="startDate">Start Date:</label>
        <DatePicker
          className="modal-input"
          value={startDate ? moment(startDate) : null}
          onChange={onChangeStartDate}
          //showTime={true}
          showTime={{ format: 'HH:mm:ss' }}
          format="YYYY-MM-DD HH:mm:ss"
          showNow={false}
        />
        <label className="modal-label" htmlFor="endDate">End Date:</label>
        <DatePicker
          className="modal-input"
          value={endDate ? moment(endDate) : null}
          onChange={onChangeEndDate}
          //showTime={true}
          showTime={{ format: 'HH:mm:ss' }}
          format="YYYY-MM-DD HH:mm:ss"
          showNow={false}
        />
      </Modal>
      {showAlert && (
        <Modal
          title="Warning"
          open={showAlert}
          onCancel={() => setShowAlert(false)}
          footer={[
            <Button key="close" onClick={() => setShowAlert(false)}>Close</Button>
          ]}
        >
          <p>Previous dates cannot be created or updated.</p>
        </Modal>
      )}
    </div>
  );
}

export default App;
